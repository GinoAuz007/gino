// app.js

// Escucha cuando el documento HTML haya sido completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    // Muestra un mensaje en la consola indicando que la aplicación se ha cargado correctamente
    console.log("Aplicación cargada correctamente");  
});

// Otro evento 'DOMContentLoaded' para asegurar que el DOM está listo antes de ejecutar el código
document.addEventListener('DOMContentLoaded', function () {
    // Selecciona el formulario (tag <form>) en el HTML para agregarle funcionalidad
    const eventoForm = document.querySelector('form');  

    // Se agrega un evento de escucha para cuando se envíe el formulario de evento
    eventoForm.addEventListener('submit', function (event) {
        // Previene el comportamiento por defecto del formulario (enviar y recargar la página)
        event.preventDefault();  

        // Se obtiene el valor de los campos del formulario y se elimina cualquier espacio extra al principio y al final
        // Obtiene el valor del campo 'eventoTitulo' y lo limpia de espacios adicionales
        const titulo = document.getElementById('eventoTitulo').value.trim();  
        // Obtiene el valor del campo 'eventoInvitados' y lo limpia de espacios adicionales
        const invitados = document.getElementById('eventoInvitados').value.trim();  
        // Obtiene el valor del campo 'eventoFechaHora' y lo limpia de espacios adicionales
        const fechaHora = document.getElementById('eventoFechaHora').value.trim();  
        // Obtiene el valor del campo 'eventoZonaHoraria' y lo limpia de espacios adicionales
        const zonaHoraria = document.getElementById('eventoZonaHoraria').value.trim();  
        // Obtiene el valor del campo 'eventoDescripcion' y lo limpia de espacios adicionales
        const descripcion = document.getElementById('eventoDescripcion').value.trim();  

        // Validación de los campos: si alguno está vacío, muestra un mensaje de error
        if (titulo === '' || invitados === '' || fechaHora === '' || zonaHoraria === '' || descripcion === '') {
           // Muestra una alerta indicando que todos los campos son obligatorios
            alert('Todos los campos son obligatorios');  
            // Si alguno de los campos está vacío, se detiene la ejecución y no se envía el formulario
            return;  
        }

        // Si todos los campos son válidos, muestra un mensaje de éxito
        // Muestra una alerta indicando que el evento fue registrado con éxito
        alert('Evento registrado con éxito');  
        // Limpia el formulario después de la validación exitosa, dejando los campos vacíos
        eventoForm.reset();  
    });
});
